const http = require('http');
const fs = require('fs');

/* Loading pages variables */

const home_page = fs.readFileSync('home.html'); 
const about_page = fs.readFileSync('about.html');
const contact_page = fs.readFileSync('contact.html');
const error_page = fs.readFileSync('error-404.html'); 

const server = http.createServer((req, res) => {
	
	console.log("you had reached server \n");
	console.log("Your requested URL is " + req.url + "\n");
	
	if(req.url === '/'){
		res.writeHead(200);
		return res.end(home_page);		
	} else if(req.url === '/about') {
		res.writeHead(200);
		return res.end(about_page);
	}
	else if(req.url === '/contact') {
		res.writeHead(200);
		return res.end(contact_page);
	}
	else {
		res.writeHead(404);
		return res.end(error_page);
	}
	
	
	
});

server.listen(3000);