"use strict";

const express = require('express');
const mongoose = require('mongoose');
const app = new express();
const path = require('path');
const bodyParser = require('body-parser');
const User = require('./database/models/users');

mongoose.connect('mongodb://localhost/node_js_learning');

/* Custom Controllers ---------------------------------------*/

const createUserController = require('./controllers/createUser');
const homeController = require('./controllers/homeController');
const aboutController = require('./controllers/aboutController');
const contactController = require('./controllers/contactController');
const errorController = require('./controllers/errorController');

const userApiController = require('./controllers/userApiController');
const getUserApiController = require('./controllers/getUserApiController');

/* Custom Middlewares ---------------------------------------*/

const userValidationMiddlewareController = require('./middlewares/userValidationMiddleware');
const getUserValidMiddlewareController = require('./middlewares/userEmailValidationMiddleware');

/* App using features ------------------------------------------------ */

app.use(express.static('public'));
app.use(require('express-edge'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/user/save', userValidationMiddlewareController);
app.use('/user/:email', getUserValidMiddlewareController);

app.set('views', `${__dirname}/views`);

app.listen(3000, () => {
	console.log('App is listening on port 3000');
});

app.get('/', homeController);

app.get('/about', aboutController);

app.get('/create_user', createUserController);

app.get('/contact', contactController);

app.get('/err', errorController);


/* API post request ------------------------------------ */

app.post('/user/save', userApiController);
app.post('/user/:email', getUserApiController);