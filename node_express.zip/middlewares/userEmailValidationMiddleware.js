module.exports = (req, res, next) => {
	if(req.params.email == "") {
		res.redirect("/");
	} else if(req.params.email.indexOf('@)') < 0) {
        res.redirect("/");		
	} else {
        next();
    }	
};