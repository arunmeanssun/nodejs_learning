module.exports = (req, res, next) => {
	if(req.body.user_name == '' || req.body.user_full_name == "" || req.body.user_email == "" || req.body.user_pass == ""  ||  req.body.user_address == "") {
		res.redirect("/create_user");
	} else {
		next();
	}	
};