const mongoose = require('mongoose');

const User = require('../../database/models/users');

mongoose.connect('mongodb://localhost/node_js_learning');

function create_user() {
    var userName = document.getElementById('user_name').nodeValue;
    var userPass = document.getElementById('user_pass').nodeValue;
    var fullName = document.getElementById('user_full_name').nodeValue;
    var userEmail = document.getElementById('user_email').nodeValue;
    var userMobile = document.getElementById('user_mobile').nodeValue;
    var userAddress = document.getElementById('user_address').nodeValue;
    var userAddressCity = document.getElementById('user_address_city').nodeValue;
    var user_address_state = document.getElementById('user_address_state').nodeValue;
    var user_address_pincode = document.getElementById('user_address_pincode').nodeValue;

    var userId = "user_" +  Math.random() * 1000000000;     

    User.create({
        user_id: userId,
        user_name: userName,
        user_pass: userPass,
        user_full_name: fullName,
        user_email: userEmail,
        user_mobile: userMobile,
        user_address: userAddress,
        user_address_city: userAddressCity,
        user_address_state: user_address_state,
        user_address_pincode: user_address_pincode
    }, (err, user_data) => {
        if(err) {
            console.log('Error Occured \n' + err);
            alert("Some Error has happened in saving the user "+ fullName + " data");
        } else {
            console.log('User Data of ' + user_data.user_name + ' is added to database' );
            alert("Details of "+ fullName + " data has been added to the database");
        }
    })
}