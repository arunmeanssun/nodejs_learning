const User = require('../database/models/users');

module.exports = (req, res) => {
    User.find({ user_email: req.params.user_email}, (err, userData) => {
        if(err) {
            console.log("there is an error occured during the search process")
        } else {
            console.log("Searced details received");
            console.log(userData);

            if(userData.length == 0){
                res.sendJSON({ response: "No data found" });
            } else {
                res.sendJSON(userData[0]);
            }
        }
    });
}