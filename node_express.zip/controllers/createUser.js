module.exports = (req, res) => {
    res.render('create_user');
}