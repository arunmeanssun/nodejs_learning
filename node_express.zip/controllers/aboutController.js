module.exports = (req, res) => {	
	// res.sendFile(path.resolve(__dirname,"pages/about.html"));
	res.render('about', { data_id: "SAK 3264", data_name: "Arun Kumar S"});	
}
