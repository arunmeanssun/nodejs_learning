module.exports = (req, res) => {	
	//res.sendFile(path.resolve(__dirname,"pages/contact.html"));
	res.render('contact');
}