const User = require('../database/models/users');

module.exports = (req, res) => {	
	//res.sendFile(path.resolve(__dirname,"pages/error-404.html"));

	/* console.log("Form object received from the client");
	console.log(req.body); */

	/* const { image } = req.files; */

	let user_received = req.body;
	let user_found = {};

	User.find({ "user_email": user_received.user_email }, (err, user) => {
		if(err) {
			console.log("there is an error occured during the search process")
		} else {
			user_found = user;

			if(user_found.length == 1){
				console.log("user "+ user_found[0].user_full_name +" already exist");
				res.redirect('/');
			}
			else {				
				User.create({
					...req.body
				}, (error,post)=> {
					if(error){
						console.log("Error occured.");
						console.log(error);
						res.redirect('/');
					} else {
						console.log("User "+ post.user_full_name +" created successfully.");
						res.redirect('/');
					}					
				});
			}
		}
	});	 
	
}