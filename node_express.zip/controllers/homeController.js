const User = require('../database/models/users');
const mongoose = require('mongoose');

module.exports = async(req, res) => {
    // console.log("server installed path \n\n" + __dirname + "\n");
    // res.sendFile(path.resolve(__dirname,"pages/home.html"));
    
    const users = await User.find({});
	res.render('index', { data_id: "SAK 3264", data_name: "Arun Kumar S", userList: users });
}