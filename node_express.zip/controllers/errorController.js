module.exports = (req, res) => {	
	//res.sendFile(path.resolve(__dirname,"pages/error-404.html"));
	res.render('error-404');
}