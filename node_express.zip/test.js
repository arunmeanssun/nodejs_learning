const mongoose = require('mongoose');

const User = require('./database/models/users');

mongoose.connect('mongodb://localhost/node_js_learning');

/* ---------------------------- database document creation ----------------------------- */ 
/* 
User.create({
    user_id: "user_171211221",
    user_name: "michael_75",
    user_pass: "12345",
    user_full_name: "Michael Fernandez",
    user_email: "michael_75@yahoo.com",
    user_mobile: 913421243213,
    user_address: "#31, Michael Apartment, North Street",
    user_address_city: "Newyork City",
    user_address_state: "Newyork",
    user_address_pincode: 34564
}, (err, user_data) => {
    if(err) {
        console.log('Error Occured \n' + err);
    } else {
        console.log('User Data of ' + user_data.user_name + ' is added to database' );
    }
}); 
*/

/* ---------------------------- Getting data from database ----------------------------- */ 

/* 
User.find({}, (err, user) => {
    if(err) {
        console.log("there is an error occured during the search process")
    } else {
        console.log("Searced details received");
        console.log(user);
    }
});

*/

/* ---------------------------- Getting data from database by document id------------------- */

/*

User.findById("5c8115881d9dba0dcc8e551b", (err, user) => {
    if(err) {
        console.log("there is an error occured during the search process")
    } else {
        console.log("Searced details received");
        console.log(user);
    }
});

*/

/* ---------------------------- updating data to database by document id------------------- */

User.findByIdAndUpdate("5c8115881d9dba0dcc8e551b", {
    user_full_name: "Michael Fernandez Potter"
}, (err, user) => {
    if(err) {
        console.log("there is an error occured during the update process")
    } else {
        console.log("the detail successfully updated");
        console.log(user);
    }
});


