const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    user_id: String,
    user_name: String,
    user_pass: String,
    user_image: String,
    user_full_name: String,
    user_email: String,
    user_mobile: Number,
    user_address: String,
    user_address_city: String,
    user_address_state: String,
    user_address_pincode: Number,
    created_on: {
        type: Date,
        default: new Date()
    }
});

const User = mongoose.model("User", UserSchema);

module.exports = User;